from rest_framework import serializers
from goodread_app.models import Book, Review


        
class BookSerializer(serializers.ModelSerializer):
    
    class Meta:
        model = Book
        fields = "__all__"