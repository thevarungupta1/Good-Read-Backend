from django.apps import AppConfig


class GoodreadAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'goodread_app'
