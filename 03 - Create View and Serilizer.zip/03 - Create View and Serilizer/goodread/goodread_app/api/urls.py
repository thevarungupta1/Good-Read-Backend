from django.urls import path, include
from rest_framework.routers import DefaultRouter
from goodread_app.api.views import (ReviewLIst, ReviewDetail, ReviewCreate, Book, BookDetail)

router = DefaultRouter()


urlpatterns = [
    path('list/', book_list, name='book-list'),
    path('<int:pk>/', book_details, name='book-detail'),
    
    path('', include(router.url))
   
]